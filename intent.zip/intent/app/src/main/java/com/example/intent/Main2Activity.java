package com.example.intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Main2Activity extends AppCompatActivity {

    private TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView2 = findViewById(R.id.resultView2);

        Intent intent = getIntent();
        //String text = intent.getStringExtra(MainActivity.extraNumber);

        int result=intent.getIntExtra(MainActivity.extraNumber,0);

        textView2.setText(result);
    }
}
