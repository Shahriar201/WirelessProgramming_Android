package com.example.intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    public static final String extraNumber = "com.example.intent";

    private EditText editText1;
    private EditText editText2;
    private Button addBtn;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        editText1 = findViewById(R.id.editText2);
        addBtn = findViewById(R.id.addButton);
        textView = findViewById(R.id.viewResult1);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int num1 = Integer.parseInt(editText1.getText().toString());
                int num2 = Integer.parseInt((editText2.getText().toString()));

                int result = num1 + num2;

                textView.setText("Answer : " + String.valueOf(result));

                //Intent intent = new Intent(MainActivity.this, Main2Activity.class);

                //String data = textView.getText().toString();
                //intent.putExtra(extraNumber, result);

               // startActivity(intent);
            }
        });
    }
}
