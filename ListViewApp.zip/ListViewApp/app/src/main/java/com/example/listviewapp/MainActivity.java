package com.example.listviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView=findViewById(R.id.listviewid);
        String[]departmentName=getResources().getStringArray(R.array.DepartmentArry);
        ArrayAdapter<String>adapter=new ArrayAdapter<String>(this,R.layout.listviewlayout,R.id.textviewId,departmentName);
        listView.setAdapter(adapter);




    }
}
